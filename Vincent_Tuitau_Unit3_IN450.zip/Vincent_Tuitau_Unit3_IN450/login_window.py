import tkinter as tk
from tkinter import messagebox
from database import Database
from app import App

def launch_main_app(db):
    main_root = tk.Tk()
    app = App(main_root, db)
    main_root.protocol("WM_DELETE_WINDOW", app.on_close)
    main_root.mainloop()

def try_login():
    try:
        db = Database(
            dbname=database_entry.get(),
            user=username_entry.get(),
            password=password_entry.get(),
            host=server_entry.get()
        )
        login_window.destroy()
        launch_main_app(db)
    except Exception as e:
        messagebox.showerror("Connection Failed", str(e))

# Login GUI
login_window = tk.Tk()
login_window.title("Database Login")

tk.Label(login_window, text="Server:").pack()
server_entry = tk.Entry(login_window)
server_entry.insert(0, "localhost")
server_entry.pack()

tk.Label(login_window, text="Database:").pack()
database_entry = tk.Entry(login_window)
database_entry.insert(0, "postgres")
database_entry.pack()

tk.Label(login_window, text="Username:").pack()
username_entry = tk.Entry(login_window)
username_entry.pack()

tk.Label(login_window, text="Password:").pack()
password_entry = tk.Entry(login_window, show="*")
password_entry.pack()

tk.Button(login_window, text="Connect", command=try_login).pack(pady=10)

login_window.mainloop()
