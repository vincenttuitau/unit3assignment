import psycopg2

class Database:
    def __init__(self, dbname, user, password, host, port="5432"):
        try:
            self.conn = psycopg2.connect(
                dbname=dbname,
                user=user,
                password=password,
                host=host,
                port=port
            )
            self.cursor = self.conn.cursor()
        except Exception as e:
            raise Exception(f"Database connection failed: {e}")

    def get_row_count(self):
        try:
            self.cursor.execute("SELECT COUNT(*) FROM in450a")
            return self.cursor.fetchone()[0]
        except Exception as e:
            self.conn.rollback()
            return f"Error: {e}"

    def get_names(self):
        try:
            self.cursor.execute("SELECT first_name, last_name FROM in450b")
            return self.cursor.fetchall()
        except Exception as e:
            self.conn.rollback()
            return f"Error: {e}"

    def get_in450c_data(self):
        try:
            self.cursor.execute("SELECT category, description FROM in450c")
            return self.cursor.fetchall()
        except Exception as e:
            self.conn.rollback()
            return f"Error: {e}"

    def close_connection(self):
        self.cursor.close()
        self.conn.close()
