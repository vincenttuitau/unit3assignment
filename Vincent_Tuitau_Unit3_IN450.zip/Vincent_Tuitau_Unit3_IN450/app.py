import tkinter as tk
from database import Database

class App:
    def __init__(self, root, db):
        self.root = root
        self.db = db
        self.root.title("IN450 Role-Based Viewer")

        # Button to count rows in in450a
        self.count_a_button = tk.Button(root, text="Count Rows (in450a)", command=self.display_row_count)
        self.count_a_button.pack(pady=5)

        # Button to show names from in450b
        self.names_button = tk.Button(root, text="Show Names (in450b)", command=self.display_names)
        self.names_button.pack(pady=5)

        # Button to show categories from in450c
        self.categories_button = tk.Button(root, text="Show Categories (in450c)", command=self.display_categories)
        self.categories_button.pack(pady=5)

        # Output area
        self.text_area = tk.Text(root, height=20, width=60)
        self.text_area.pack(padx=10, pady=10)

    def display_row_count(self):
        self.text_area.delete('1.0', tk.END)
        result = self.db.get_row_count()
        if isinstance(result, str):
            self.text_area.insert(tk.END, result + "\n")
        else:
            self.text_area.insert(tk.END, f"Rows in in450a: {result}\n")

    def display_names(self):
        self.text_area.delete('1.0', tk.END)
        result = self.db.get_names()
        if isinstance(result, str):
            self.text_area.insert(tk.END, result + "\n")
        else:
            self.text_area.insert(tk.END, "--- Names in in450b ---\n")
            for first, last in result:
                self.text_area.insert(tk.END, f"{first} {last}\n")

    def display_categories(self):
        self.text_area.delete('1.0', tk.END)
        result = self.db.get_in450c_data()
        if isinstance(result, str):
            self.text_area.insert(tk.END, result + "\n")
        else:
            self.text_area.insert(tk.END, "--- Categories in in450c ---\n")
            for category, description in result:
                self.text_area.insert(tk.END, f"{category}: {description}\n")

    def on_close(self):
        self.db.close_connection()
        self.root.destroy()
