import psycopg2

class Database:
    def __init__(self, dbname="postgres", user="postgres", password="your_password", host="localhost", port="5432"):
        """Initialize database connection."""
        self.conn = psycopg2.connect(dbname="postgres", user="postgres", password="Sp!derm@n187490", host="localhost", port="5432"
)

        self.cursor = self.conn.cursor()

    def get_row_count(self):
        """Fetch the number of rows in in450a."""
        self.cursor.execute("SELECT COUNT(*) FROM in450a;")
        return self.cursor.fetchone()[0]

    def get_names(self):
        """Retrieve first and last names from in450b."""
        self.cursor.execute("SELECT first_name, last_name FROM in450b;")
        return self.cursor.fetchall()

    def get_in450c_data(self):
        """Retrieve category and description from in450c."""
        self.cursor.execute("SELECT category, description FROM in450c;")
        return self.cursor.fetchall()

    def close_connection(self):
        """Close the database connection."""
        self.conn.close()
