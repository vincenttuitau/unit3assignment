import tkinter as tk
from database import Database

class App:
    def __init__(self, root):
        """Initialize the GUI and database connection."""
        self.db = Database()
        self.root = root
        self.root.title("PostgreSQL GUI")

        # Button to get row count from in450a
        self.count_button = tk.Button(root, text="Count Rows (in450a)", command=self.display_row_count)
        self.count_button.pack()

        # Button to display first and last names from in450b
        self.names_button = tk.Button(root, text="Show Names (in450b)", command=self.display_names)
        self.names_button.pack()

        # Button to display category and description from in450c
        self.in450c_button = tk.Button(root, text="Show Categories (in450c)", command=self.display_in450c_data)
        self.in450c_button.pack()

        # Text area for displaying output
        self.text_area = tk.Text(root, height=20, width=60)
        self.text_area.pack()

    def display_row_count(self):
        """Fetch and display row count for in450a."""
        self.text_area.delete('1.0', tk.END)  # Clear previous text
        count = self.db.get_row_count()
        self.text_area.insert(tk.END, f"Rows in in450a: {count}\n")

    def display_names(self):
        """Fetch and display first and last names from in450b."""
        self.text_area.delete('1.0', tk.END)  # Clear previous text
        names = self.db.get_names()
        self.text_area.insert(tk.END, "\n--- Names in in450b ---\n")
        for first, last in names:
            self.text_area.insert(tk.END, f"{first} {last}\n")

    def display_in450c_data(self):
        """Fetch and display category and description from in450c."""
        self.text_area.delete('1.0', tk.END)  # Clear previous text
        data = self.db.get_in450c_data()
        self.text_area.insert(tk.END, "\n--- Categories in in450c ---\n")
        for category, description in data:
            self.text_area.insert(tk.END, f"{category}: {description}\n")

    def on_close(self):
        """Close database connection on exit."""
        self.db.close_connection()
        self.root.destroy()

# Run the GUI application
root = tk.Tk()
app = App(root)
root.protocol("WM_DELETE_WINDOW", app.on_close)
root.mainloop()
